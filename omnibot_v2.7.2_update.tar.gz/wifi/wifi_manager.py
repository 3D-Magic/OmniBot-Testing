"""
WiFi Manager
Handles WiFi network scanning and connections
"""

import subprocess
import logging
from typing import List, Dict

logger = logging.getLogger(__name__)


class WiFiManager:
    """Manages WiFi connections"""
    
    def __init__(self, interface='wlan0'):
        self.interface = interface
    
    def scan_networks(self) -> List[Dict]:
        """Scan for available WiFi networks"""
        networks = []
        
        # Try nmcli first (NetworkManager - most reliable)
        try:
            result = subprocess.run(
                ['nmcli', '-t', '-f', 'SSID,SIGNAL,SECURITY', 'dev', 'wifi', 'list'],
                capture_output=True, text=True, timeout=10
            )
            
            if result.returncode == 0:
                seen = set()
                for line in result.stdout.strip().split('\n'):
                    if not line or ':' not in line:
                        continue
                    
                    parts = line.split(':')
                    if len(parts) >= 2:
                        ssid = parts[0]
                        signal = parts[1] if len(parts) > 1 and parts[1] else '0'
                        security = parts[2] if len(parts) > 2 else ''
                        
                        if ssid and ssid not in seen:
                            seen.add(ssid)
                            networks.append({
                                'ssid': ssid,
                                'quality': min(int(signal), 100) if signal.isdigit() else 50,
                                'secured': bool(security and security != '--')
                            })
                
                if networks:
                    networks.sort(key=lambda x: x.get('quality', 0), reverse=True)
                    return networks[:10]
        except Exception as e:
            logger.debug(f"[WIFI] nmcli failed: {e}")
        
        # Fallback to iwlist
        try:
            result = subprocess.run(
                ['sudo', 'iwlist', self.interface, 'scan'],
                capture_output=True, text=True, timeout=30
            )
            
            current_network = {}
            
            for line in result.stdout.split('\n'):
                line = line.strip()
                
                # ESSID (network name)
                if 'ESSID:' in line:
                    essid = line.split('ESSID:')[1].strip().strip('"')
                    if essid and essid not in [n['ssid'] for n in networks]:
                        current_network = {'ssid': essid, 'secured': True, 'quality': 50}
                        networks.append(current_network)
                
                # Encryption/Security
                if 'Encryption key:' in line:
                    if 'off' in line.lower():
                        current_network['secured'] = False
                
                # Signal quality
                if 'Quality=' in line or 'Signal level=' in line:
                    try:
                        if 'Quality=' in line:
                            quality_str = line.split('Quality=')[1].split()[0]
                            if '/' in quality_str:
                                num, denom = quality_str.split('/')
                                current_network['quality'] = int(int(num) / int(denom) * 100)
                    except:
                        pass
            
            if networks:
                networks.sort(key=lambda x: x.get('quality', 0), reverse=True)
                return networks[:10]
                
        except Exception as e:
            logger.error(f"[WIFI SCAN ERROR] {e}")
        
        return networks
    
    def get_status(self) -> Dict:
        """Get current WiFi connection status"""
        try:
            # Try nmcli first
            try:
                result = subprocess.run(
                    ['nmcli', '-t', '-f', 'ACTIVE,SSID', 'connection', 'show', '--active'],
                    capture_output=True, text=True, timeout=5
                )
                
                if result.returncode == 0:
                    for line in result.stdout.strip().split('\n'):
                        if line.startswith('yes:'):
                            ssid = line.split(':')[1]
                            # Get IP
                            ip_result = subprocess.run(
                                ['hostname', '-I'],
                                capture_output=True, text=True
                            )
                            ip = ip_result.stdout.strip().split()[0] if ip_result.stdout else None
                            
                            return {
                                'connected': True,
                                'ssid': ssid,
                                'ip': ip or 'Unknown',
                                'interface': self.interface
                            }
            except:
                pass
            
            # Fallback to iwgetid
            result = subprocess.run(
                ['iwgetid', '-r'],
                capture_output=True, text=True
            )
            ssid = result.stdout.strip()
            
            # Get IP address
            ip_result = subprocess.run(
                ['hostname', '-I'],
                capture_output=True, text=True
            )
            ip = ip_result.stdout.strip().split()[0] if ip_result.stdout else None
            
            return {
                'connected': bool(ssid),
                'ssid': ssid or 'Not Connected',
                'ip': ip or 'Unknown',
                'interface': self.interface
            }
            
        except Exception as e:
            logger.error(f"[WIFI STATUS ERROR] {e}")
            return {
                'connected': False,
                'ssid': 'Unknown',
                'ip': 'Unknown',
                'error': str(e)
            }
    
    def connect(self, ssid: str, password: str = '') -> Dict:
        """Connect to a WiFi network"""
        try:
            if not ssid:
                return {'success': False, 'error': 'SSID required'}
            
            # Try nmcli first
            try:
                if password:
                    result = subprocess.run(
                        ['nmcli', 'dev', 'wifi', 'connect', ssid, 'password', password],
                        capture_output=True, text=True, timeout=30
                    )
                else:
                    result = subprocess.run(
                        ['nmcli', 'dev', 'wifi', 'connect', ssid],
                        capture_output=True, text=True, timeout=30
                    )
                
                if result.returncode == 0:
                    logger.info(f"[WIFI] Connected to {ssid}")
                    return {
                        'success': True,
                        'message': f'Connected to {ssid}'
                    }
                else:
                    return {
                        'success': False,
                        'error': result.stderr or 'Connection failed'
                    }
            except Exception as e:
                logger.debug(f"[WIFI] nmcli connect failed: {e}")
            
            # Fallback to wpa_supplicant
            if password:
                result = subprocess.run(
                    ['wpa_passphrase', ssid, password],
                    capture_output=True, text=True, timeout=10
                )
                
                if result.returncode == 0:
                    with open('/tmp/wpa_supplicant_add.conf', 'w') as f:
                        f.write(result.stdout)
                    
                    subprocess.run(
                        ['sudo', 'wpa_cli', 'reconfigure'],
                        capture_output=True
                    )
                    
                    logger.info(f"[WIFI] Connected to {ssid}")
                    return {
                        'success': True,
                        'message': f'Connected to {ssid}'
                    }
            else:
                subprocess.run(
                    ['sudo', 'iwconfig', self.interface, 'essid', ssid],
                    capture_output=True
                )
                
                logger.info(f"[WIFI] Connected to open network {ssid}")
                return {
                    'success': True,
                    'message': f'Connected to {ssid} (open network)'
                }
                
        except Exception as e:
            logger.error(f"[WIFI CONNECT ERROR] {e}")
            return {'success': False, 'error': str(e)}
    
    def disconnect(self) -> Dict:
        """Disconnect from current network"""
        try:
            # Try nmcli first
            try:
                result = subprocess.run(
                    ['nmcli', 'connection', 'down', self.interface],
                    capture_output=True, text=True, timeout=10
                )
                if result.returncode == 0:
                    return {'success': True, 'message': 'Disconnected'}
            except:
                pass
            
            # Fallback
            subprocess.run(
                ['sudo', 'iwconfig', self.interface, 'essid', 'off/any'],
                capture_output=True
            )
            return {'success': True, 'message': 'Disconnected'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
