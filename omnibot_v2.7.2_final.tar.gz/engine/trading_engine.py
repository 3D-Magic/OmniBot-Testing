"""
Trading Engine
Core trading logic and order execution
"""

import threading
import time
import logging
from enum import Enum
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class OrderSide(Enum):
    BUY = "buy"
    SELL = "sell"


class OrderType(Enum):
    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"


class TradingStrategy(Enum):
    CONSERVATIVE = "conservative"
    MODERATE = "moderate"
    AGGRESSIVE = "aggressive"


class TradingEngine:
    """Main trading engine with risk management"""
    
    def __init__(self, balance_aggregator, settings):
        self.balance_aggregator = balance_aggregator
        self.settings = settings
        self.is_running = False
        self.thread = None
        self.positions = {}
        self.orders = []
        
        # Risk management settings
        self.max_position_pct = 10.0  # Max 10% per position
        self.stop_loss_pct = 5.0      # 5% stop loss
        self.take_profit_pct = 10.0   # 10% take profit
        
    def start(self) -> bool:
        """Start the trading engine"""
        if self.is_running:
            return False
        
        self.is_running = True
        self.thread = threading.Thread(target=self._trading_loop)
        self.thread.daemon = True
        self.thread.start()
        
        logger.info(f"[ENGINE] Trading engine started")
        return True
    
    def stop(self):
        """Stop the trading engine"""
        self.is_running = False
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("[ENGINE] Trading engine stopped")
    
    def _trading_loop(self):
        """Main trading loop"""
        while self.is_running:
            try:
                # Only trade if enabled
                if not self.settings.get('trading_enabled', False):
                    time.sleep(5)
                    continue
                
                # Check positions and manage risk
                self._check_stop_losses()
                self._check_take_profits()
                
                # Evaluate strategies
                self._evaluate_strategies()
                
                time.sleep(5)  # 5 second loop
                
            except Exception as e:
                logger.error(f"[ENGINE ERROR] {e}")
                time.sleep(10)
    
    def place_order(self, symbol: str, side: OrderSide, quantity: float,
                   order_type: OrderType = OrderType.MARKET,
                   broker: str = 'alpaca', limit_price: float = None) -> Optional[Dict]:
        """Place an order through specified broker"""
        try:
            broker_obj = self.balance_aggregator.get_broker(broker)
            
            if not broker_obj or not broker_obj.connected:
                logger.error(f"[ORDER ERROR] {broker} not connected")
                return None
            
            # Demo mode - just log the order
            if self.settings.get('trading_mode') == 'demo':
                order = {
                    'id': f"demo_{int(time.time())}",
                    'symbol': symbol,
                    'side': side.value,
                    'quantity': quantity,
                    'type': order_type.value,
                    'broker': broker,
                    'status': 'filled',
                    'timestamp': time.time()
                }
                self.orders.append(order)
                logger.info(f"[DEMO ORDER] {side.value.upper()} {quantity} {symbol}")
                return order
            
            # Live trading would execute here
            logger.info(f"[ORDER] {side.value.upper()} {quantity} {symbol} via {broker}")
            return None
            
        except Exception as e:
            logger.error(f"[ORDER ERROR] {e}")
            return None
    
    def sell_all_positions(self, broker: str = 'all'):
        """Sell all positions"""
        logger.info(f"[ENGINE] Selling all positions for {broker}")
        
        brokers = ['alpaca', 'binance', 'ibkr'] if broker == 'all' else [broker]
        
        for b in brokers:
            broker_obj = self.balance_aggregator.get_broker(b)
            if broker_obj and broker_obj.connected:
                try:
                    if b == 'alpaca':
                        positions = broker_obj.get_positions()
                        for pos in positions:
                            self.place_order(
                                pos['symbol'], OrderSide.SELL,
                                pos['qty'], broker='alpaca'
                            )
                    
                    elif b == 'binance':
                        balances = broker_obj.get_all_balances()
                        for asset, amount in balances.items():
                            if asset not in ['USDT', 'BUSD'] and amount > 0:
                                symbol = f"{asset}USDT"
                                self.place_order(
                                    symbol, OrderSide.SELL,
                                    amount, broker='binance'
                                )
                
                except Exception as e:
                    logger.error(f"[SELL ALL ERROR] {b}: {e}")
    
    def _check_stop_losses(self):
        """Check and execute stop losses on open positions"""
        try:
            # Get all positions from brokers
            for broker_name in ['alpaca', 'binance', 'ibkr']:
                broker = self.balance_aggregator.get_broker(broker_name)
                if not broker or not broker.connected:
                    continue
                
                if broker_name == 'alpaca':
                    positions = broker.get_positions()
                    for pos in positions:
                        symbol = pos['symbol']
                        entry_price = pos.get('avg_entry_price', 0)
                        current_price = pos.get('current_price', entry_price)
                        qty = pos['qty']
                        
                        if entry_price > 0:
                            loss_pct = (entry_price - current_price) / entry_price * 100
                            if loss_pct >= self.stop_loss_pct:
                                logger.warning(f"[STOP LOSS] {symbol} at -{loss_pct:.2f}%")
                                self.place_order(symbol, OrderSide.SELL, qty, broker='alpaca')
        
        except Exception as e:
            logger.error(f"[STOP LOSS ERROR] {e}")
    
    def _check_take_profits(self):
        """Check and execute take profits on open positions"""
        try:
            for broker_name in ['alpaca', 'binance', 'ibkr']:
                broker = self.balance_aggregator.get_broker(broker_name)
                if not broker or not broker.connected:
                    continue
                
                if broker_name == 'alpaca':
                    positions = broker.get_positions()
                    for pos in positions:
                        symbol = pos['symbol']
                        entry_price = pos.get('avg_entry_price', 0)
                        current_price = pos.get('current_price', entry_price)
                        qty = pos['qty']
                        
                        if entry_price > 0:
                            profit_pct = (current_price - entry_price) / entry_price * 100
                            if profit_pct >= self.take_profit_pct:
                                logger.info(f"[TAKE PROFIT] {symbol} at +{profit_pct:.2f}%")
                                self.place_order(symbol, OrderSide.SELL, qty, broker='alpaca')
        
        except Exception as e:
            logger.error(f"[TAKE PROFIT ERROR] {e}")
    
    def _evaluate_strategies(self):
        """Evaluate trading strategies and generate signals"""
        strategy = self.settings.get('strategy', 'moderate')
        
        # Get total portfolio value
        total_value = self.balance_aggregator.get_total_capital()
        if total_value <= 0:
            return
        
        # Calculate position size based on strategy
        if strategy == 'conservative':
            max_position_value = total_value * 0.05  # 5% max per position
            min_confidence = 0.8
        elif strategy == 'moderate':
            max_position_value = total_value * 0.10  # 10% max per position
            min_confidence = 0.6
        else:  # aggressive
            max_position_value = total_value * 0.15  # 15% max per position
            min_confidence = 0.4
        
        # Evaluate signals (this would integrate with signal generators)
        # For now, just log the strategy check
        logger.debug(f"[STRATEGY] {strategy} - Max position: ${max_position_value:.2f}")
    
    def can_place_order(self, symbol: str, quantity: float, price: float) -> bool:
        """Check if an order can be placed based on risk management"""
        total_value = self.balance_aggregator.get_total_capital()
        if total_value <= 0:
            return False
        
        position_value = quantity * price
        position_pct = (position_value / total_value) * 100
        
        if position_pct > self.max_position_pct:
            logger.warning(f"[RISK] Order exceeds max position size: {position_pct:.1f}%")
            return False
        
        return True
    
    def get_portfolio_value(self) -> float:
        """Get total portfolio value"""
        return self.balance_aggregator.get_total_capital()
    
    def get_status(self) -> Dict:
        """Get engine status"""
        return {
            'running': self.is_running,
            'mode': self.settings.get('trading_mode', 'demo'),
            'strategy': self.settings.get('strategy', 'moderate'),
            'trading_enabled': self.settings.get('trading_enabled', False),
            'positions_count': len(self.positions),
            'orders_count': len(self.orders)
        }
